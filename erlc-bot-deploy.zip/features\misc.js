import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';
import { isStaff, isAdmin, errEmbed, okEmbed, infoEmbed, COLOR } from '../util.js';
import { panel } from '../theme.js';

const parseColor = (s) => {
    if (!s) return undefined;
    const n = parseInt(String(s).replace('#', ''), 16);
    return Number.isNaN(n) ? undefined : n;
};

export const slash = [
    new SlashCommandBuilder().setName('ping').setDescription('Check bot latency'),
    new SlashCommandBuilder().setName('membercount').setDescription('Member, online & boost counts'),
    new SlashCommandBuilder().setName('say').setDescription('Make the bot say something')
        .addStringOption(o => o.setName('message').setDescription('What to say').setRequired(true))
        .addChannelOption(o => o.setName('channel').setDescription('Target channel')),
    new SlashCommandBuilder().setName('dm').setDescription('Send a DM to a user or role')
        .addMentionableOption(o => o.setName('target').setDescription('User or role').setRequired(true))
        .addStringOption(o => o.setName('message').setDescription('Message').setRequired(true)),
    new SlashCommandBuilder().setName('embed').setDescription('Create a custom V2 formatted embed')
        .addStringOption(o => o.setName('title').setDescription('Title'))
        .addStringOption(o => o.setName('description').setDescription('Body text'))
        .addStringOption(o => o.setName('banner').setDescription('Banner image URL'))
        .addStringOption(o => o.setName('color').setDescription('Hex color e.g. #2b6cb0'))
        .addChannelOption(o => o.setName('channel').setDescription('Target channel (default: here)'))
        .addBooleanOption(o => o.setName('ping').setDescription('Ping the community role')),
    new SlashCommandBuilder().setName('embedsender').setDescription('Send an embed message to a channel')
        .addChannelOption(o => o.setName('channel').setDescription('Target channel').setRequired(true))
        .addStringOption(o => o.setName('title').setDescription('Title'))
        .addStringOption(o => o.setName('description').setDescription('Body text'))
        .addStringOption(o => o.setName('banner').setDescription('Banner image URL')),
    new SlashCommandBuilder().setName('channel').setDescription('Channel tools')
        .addSubcommand(s => s.setName('rename').setDescription('Rename a channel')
            .addStringOption(o => o.setName('name').setDescription('New name').setRequired(true))
            .addChannelOption(o => o.setName('channel').setDescription('Channel (default: here)'))),
    new SlashCommandBuilder().setName('help').setDescription('View all slash & prefix commands')
];
export const owns = ['ping', 'membercount', 'say', 'dm', 'embed', 'embedsender', 'channel', 'help'];
export const prefixOwns = ['ping', 'membercount', 'say', 'dm', 'help'];

export async function handleSlash(interaction) {
    const name = interaction.commandName;
    const g = interaction.guild;

    if (name === 'ping') return interaction.reply({ embeds: [okEmbed(`🏓 Pong! \`${Math.round(interaction.client.ws.ping)}ms\` websocket.`)] });

    if (name === 'membercount') {
        await g.members.fetch().catch(() => {});
        const online = g.members.cache.filter(m => m.presence && m.presence.status !== 'offline').size;
        return interaction.reply({ embeds: [infoEmbed(`📊 ${g.name}`).addFields(
            { name: 'Total Members', value: `${g.memberCount}`, inline: true },
            { name: 'Online', value: `${online}`, inline: true },
            { name: 'Boosts', value: `${g.premiumSubscriptionCount ?? 0}`, inline: true })] });
    }

    if (name === 'say') {
        if (!isStaff(interaction.member)) return interaction.reply({ embeds: [errEmbed('Staff only.')], ephemeral: true });
        const ch = interaction.options.getChannel('channel') || interaction.channel;
        await ch.send({ content: interaction.options.getString('message'), allowedMentions: { parse: [] } });
        return interaction.reply({ embeds: [okEmbed(`✅ Sent in ${ch}.`)], ephemeral: true });
    }

    if (name === 'dm') {
        if (!isStaff(interaction.member)) return interaction.reply({ embeds: [errEmbed('Staff only.')], ephemeral: true });
        const target = interaction.options.getMentionable('target');
        const msg = interaction.options.getString('message');
        await interaction.deferReply({ ephemeral: true });
        const embed = infoEmbed(`📩 Message from ${g.name}`, msg);
        if (target.user) { // a member
            await target.send({ embeds: [embed] }).catch(() => {});
            return interaction.editReply({ embeds: [okEmbed(`✅ DM sent to ${target}.`)] });
        }
        // a role → DM each member (capped)
        const members = [...target.members.values()].slice(0, 50);
        let n = 0;
        for (const m of members) { if (!m.user.bot && await m.send({ embeds: [embed] }).then(() => true).catch(() => false)) n++; }
        return interaction.editReply({ embeds: [okEmbed(`✅ DM sent to ${n}/${members.length} members of ${target}.`)] });
    }

    if (name === 'embed' || name === 'embedsender') {
        if (!isStaff(interaction.member)) return interaction.reply({ embeds: [errEmbed('Staff only.')], ephemeral: true });
        const title = interaction.options.getString('title');
        const description = interaction.options.getString('description');
        const banner = interaction.options.getString('banner');
        const ping = name === 'embed' ? interaction.options.getBoolean('ping') : false;
        const color = name === 'embed' ? parseColor(interaction.options.getString('color')) : undefined;
        const ch = interaction.options.getChannel('channel') || interaction.channel;
        if (!title && !description && !banner) return interaction.reply({ embeds: [errEmbed('Provide at least a title, description, or banner.')], ephemeral: true });

        await ch.send(panel({ guildId: g.id, kind: 'default', title, body: description, bannerUrl: banner, color, ping: ping ? true : undefined }));
        return interaction.reply({ embeds: [okEmbed(`✅ Embed sent in ${ch}.`)], ephemeral: true });
    }

    if (name === 'channel') {
        if (!isAdmin(interaction.member)) return interaction.reply({ embeds: [errEmbed('Admin only.')], ephemeral: true });
        const ch = interaction.options.getChannel('channel') || interaction.channel;
        const newName = interaction.options.getString('name');
        await ch.setName(newName).catch(() => {});
        return interaction.reply({ embeds: [okEmbed(`✅ Renamed to **${newName}**.`)], ephemeral: true });
    }

    if (name === 'help') return interaction.reply({ embeds: [helpEmbed()], ephemeral: true });
}

function helpEmbed() {
    return new EmbedBuilder().setColor(COLOR).setTitle('📖 ERLC Bot — Commands').addFields(
        { name: '🚓 ERLC', value: '`/erlc server|players|joinlogs|killlogs|commandlogs|bans|vehicles|queue|command`\n`u!erlc <view>` · `u!run :<raw>` · `u!heal/mod/admin/kick/ban/jail/pm/h/weather/time…`' },
        { name: '📅 Sessions', value: '`/session info|ssu|ssd|boost|full|vote` · `u!session …` · `u!shutdown`' },
        { name: '🎉 Giveaways', value: '`/giveaway start|end|reroll` · `u!giveaway create|end|reroll`' },
        { name: '🛡️ Staff', value: '`/infraction add|remove|list` · `/promotion add|history` · `/review` · `/training request|results` · `u!infraction` · `u!promotion`' },
        { name: '🎫 Tickets', value: '`/ticket setup|close|forceclose` · `/adduser` · `/removeuser` · `/close-all-tickets` · `u!ticket close`' },
        { name: '💡 Community', value: '`/suggest` · `/roleplay log|revoke` · `/afk-set` · `/afk-remove` · `u!afk` · `u!suggestion`' },
        { name: '🔧 Utility', value: '`/say` · `/dm` · `/embed` · `/embedsender` · `/channel rename` · `/membercount` · `/ping` · `/help`' },
        { name: '⚙️ Config', value: '`/setup` · `/debug` · `/reset-config` (admin)' }
    );
}

export async function handlePrefix(cmd, message, args, rest) {
    const g = message.guild;
    if (cmd === 'ping') return message.reply({ embeds: [okEmbed(`🏓 Pong! \`${Math.round(message.client.ws.ping)}ms\``)] }).catch(() => {});
    if (cmd === 'help') return message.reply({ embeds: [helpEmbed()] }).catch(() => {});
    if (cmd === 'membercount') return message.reply({ embeds: [infoEmbed(`📊 ${g.name}`, `**Total:** ${g.memberCount}\n**Boosts:** ${g.premiumSubscriptionCount ?? 0}`)] }).catch(() => {});

    if (cmd === 'say') {
        if (!isStaff(message.member)) return message.reply({ embeds: [errEmbed('Staff only.')] }).catch(() => {});
        if (!rest) return message.reply({ embeds: [errEmbed('Usage: `u!say <message>`')] }).catch(() => {});
        await message.delete().catch(() => {});
        return message.channel.send({ content: rest, allowedMentions: { parse: [] } }).catch(() => {});
    }
    if (cmd === 'dm') {
        if (!isStaff(message.member)) return message.reply({ embeds: [errEmbed('Staff only.')] }).catch(() => {});
        const user = message.mentions.users.first();
        const body = rest.replace(/<@!?\d+>/, '').trim();
        if (!user || !body) return message.reply({ embeds: [errEmbed('Usage: `u!dm @user <message>`')] }).catch(() => {});
        const ok = await user.send({ embeds: [infoEmbed(`📩 Message from ${g.name}`, body)] }).then(() => true).catch(() => false);
        return message.reply({ embeds: [ok ? okEmbed(`✅ DM sent to ${user}.`) : errEmbed('Could not DM that user.')] }).catch(() => {});
    }
}
