import { SlashCommandBuilder } from 'discord.js';
import { guild, persist } from '../store.js';
import { isStaff, errEmbed, okEmbed, resolveChannel, safeReply, now } from '../util.js';
import { panel, branding } from '../theme.js';

const cfg = (gid) => guild(gid).config;

export const slash = [
    new SlashCommandBuilder().setName('training').setDescription('Trainings')
        .addSubcommand(s => s.setName('request').setDescription('Request a training')
            .addStringOption(o => o.setName('type').setDescription('Training type').setRequired(true))
            .addStringOption(o => o.setName('when').setDescription('When (e.g. "Today 5PM EST")').setRequired(true)))
        .addSubcommand(s => s.setName('results').setDescription('Post training results')
            .addStringOption(o => o.setName('type').setDescription('Training type').setRequired(true))
            .addStringOption(o => o.setName('passed').setDescription('Who passed (mention or names)').setRequired(true))
            .addStringOption(o => o.setName('notes').setDescription('Notes')))
];
export const owns = ['training'];

export async function handleSlash(interaction) {
    const g = interaction.guild;
    const sub = interaction.options.getSubcommand();
    const ch = (await resolveChannel(g, cfg(g.id).trainingChannel)) || interaction.channel;
    const data = guild(g.id);

    if (sub === 'request') {
        const type = interaction.options.getString('type');
        const when = interaction.options.getString('when');
        data.trainings.push({ id: (data.trainingSeq = (data.trainingSeq || 0) + 1), type, when, host: interaction.user.id, status: 'requested', ts: now() });
        persist();
        await ch.send(panel({
            guildId: g.id, kind: 'training', title: '🎓 Training Requested',
            body: 'A training has been requested. React/attend if interested!',
            fields: [{ name: 'Type', value: type }, { name: 'When', value: when }, { name: 'Requested by', value: `<@${interaction.user.id}>` }],
            ping: branding(g.id).pingRole ? true : undefined
        }));
        return interaction.reply({ embeds: [okEmbed(`✅ Training request posted in ${ch}.`)], ephemeral: true });
    }

    // results — staff only
    if (!isStaff(interaction.member)) return safeReply(interaction, { embeds: [errEmbed('Staff only.')], ephemeral: true });
    await ch.send(panel({
        guildId: g.id, kind: 'training', title: '🎓 Training Results',
        fields: [
            { name: 'Type', value: interaction.options.getString('type') },
            { name: 'Passed', value: interaction.options.getString('passed') },
            { name: 'Notes', value: interaction.options.getString('notes') || '—' },
            { name: 'Host', value: `<@${interaction.user.id}>` }
        ]
    }));
    return interaction.reply({ embeds: [okEmbed(`✅ Results posted in ${ch}.`)], ephemeral: true });
}
