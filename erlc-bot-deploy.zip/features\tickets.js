import {
    SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle,
    StringSelectMenuBuilder, ChannelType, PermissionFlagsBits, AttachmentBuilder
} from 'discord.js';
import { guild, persist } from '../store.js';
import { isStaff, isSupport, isAdmin, errEmbed, okEmbed, infoEmbed, resolveChannel, csv } from '../util.js';
import { panel, branding } from '../theme.js';

const cfg = (gid) => guild(gid).config;

// Seeded on first use so the panel ships with these out of the box. Staff can
// still add/remove types or set each one's category/ping role afterwards.
const DEFAULT_TICKET_TYPES = [
    { id: 'general-support', label: 'General Support', emoji: '🛠️', description: 'Questions & general help', category: null, pingRole: null, supportRoles: null },
    { id: 'staff-report',    label: 'Staff Report',    emoji: '🚨', description: 'Report a staff member or player', category: null, pingRole: null, supportRoles: null },
    { id: 'fastpass',        label: 'Fastpass',        emoji: '🎟️', description: 'Fastpass / priority requests', category: null, pingRole: null, supportRoles: null },
    { id: 'management',      label: 'Management',      emoji: '💼', description: 'Sensitive / management only', category: null, pingRole: null, supportRoles: null }
];

function types(gid) {
    const c = cfg(gid);
    if (!c.ticketTypes) c.ticketTypes = [];
    if (!c.ticketTypesSeeded) {
        c.ticketTypes = DEFAULT_TICKET_TYPES.map(t => ({ ...t }));
        c.ticketTypesSeeded = true;
        persist();
    }
    return c.ticketTypes;
}

const slugify = (s) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 20) || 'ticket';

// Panel components: a dropdown if types are configured, else a single button.
function panelComponents(gid) {
    const list = types(gid);
    if (!list.length) {
        return new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('ticket:open').setLabel('🎫 Open Ticket').setStyle(ButtonStyle.Primary));
    }
    const menu = new StringSelectMenuBuilder().setCustomId('ticket:open').setPlaceholder('Select a ticket type…');
    for (const t of list.slice(0, 25)) {
        const opt = { label: t.label.slice(0, 100), value: t.id, description: (t.description || '').slice(0, 100) || undefined };
        if (t.emoji) opt.emoji = t.emoji;
        menu.addOptions(opt);
    }
    return new ActionRowBuilder().addComponents(menu);
}
// 🔴 unclaimed / 🟢 claimed, followed by the opener's username.
function ticketChannelName(claimed, username) {
    return `${claimed ? '🟢' : '🔴'}-${slugify(username)}`;
}
function typeLabel(gid, id) {
    const ty = types(gid).find(t => t.id === id);
    return ty ? ty.label : 'Ticket';
}
function controlRow(t) {
    const claimed = !!t.claimedBy;
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('ticket:claim').setLabel(claimed ? 'Unclaim' : 'Claim').setStyle(claimed ? ButtonStyle.Success : ButtonStyle.Secondary).setEmoji(claimed ? '🟢' : '🟡'),
        new ButtonBuilder().setCustomId('ticket:close').setLabel('Close').setStyle(ButtonStyle.Danger).setEmoji('🔒'));
}
// The pinned status/control panel inside a ticket.
function ticketPanel(gid, t) {
    const status = t.claimedBy ? `🟢 **Claimed** by <@${t.claimedBy}>` : '🔴 **Unclaimed** — waiting for staff';
    const p = panel({
        guildId: gid, kind: 'tickets', title: `🎫 ${typeLabel(gid, t.type)} #${t.number}`,
        body: `Welcome <@${t.userId}>! Describe your issue and a staff member will assist.\n\n**Status:** ${status}`,
        footer: branding(gid).name || undefined
    });
    p.components.push(controlRow(t));
    return p;
}

function supportRoleIds(g, type) {
    return [...csv(cfg(g.id).supportRoles), ...csv(type?.supportRoles)];
}

async function createTicket(g, member, type) {
    const data = guild(g.id);
    data.ticketCounter = (data.ticketCounter || 0) + 1;
    const num = data.ticketCounter;

    const overwrites = [
        { id: g.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
        { id: member.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
        { id: g.members.me.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels] }
    ];
    for (const rid of supportRoleIds(g, type)) {
        if (g.roles.cache.has(rid)) overwrites.push({ id: rid, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] });
    }

    const ch = await g.channels.create({
        name: ticketChannelName(false, member.user.username),
        type: ChannelType.GuildText,
        parent: type?.category || cfg(g.id).ticketCategory || undefined,
        permissionOverwrites: overwrites
    });
    const t = { userId: member.id, username: member.user.username, claimedBy: null, openedAt: Date.now(), number: num, type: type?.id || null, panelMessageId: null };
    data.tickets[ch.id] = t;
    persist();

    const ping = [`<@${member.id}>`];
    if (type?.pingRole) ping.push(`<@&${type.pingRole}>`);
    const sent = await ch.send({ content: ping.join(' '), ...ticketPanel(g.id, t), allowedMentions: { users: [member.id], roles: type?.pingRole ? [type.pingRole] : [] } });
    t.panelMessageId = sent.id;
    persist();
    return ch;
}

async function closeTicket(g, channel, closedBy) {
    const t = guild(g.id).tickets[channel.id];
    if (!t) return false;
    let transcript = `Ticket #${t.number} (${t.type || 'general'}) — opened by ${t.userId}\nClosed by ${closedBy.tag} at ${new Date().toISOString()}\n\n`;
    try {
        const msgs = await channel.messages.fetch({ limit: 100 });
        transcript += [...msgs.values()].reverse()
            .map(m => `[${new Date(m.createdTimestamp).toISOString()}] ${m.author.tag}: ${m.content || '[embed/attachment]'}`).join('\n');
    } catch { /* ignore */ }

    const logCh = await resolveChannel(g, cfg(g.id).ticketLogChannel);
    if (logCh) {
        const file = new AttachmentBuilder(Buffer.from(transcript, 'utf8'), { name: `ticket-${t.number}.txt` });
        await logCh.send({ embeds: [okEmbed(`🎫 **Ticket #${t.number}** (${t.type || 'general'}) closed by ${closedBy} — opened by <@${t.userId}>.`)], files: [file] }).catch(() => {});
    }
    delete guild(g.id).tickets[channel.id];
    persist();
    await channel.delete(`Ticket closed by ${closedBy.tag}`).catch(() => {});
    return true;
}

export const slash = [
    new SlashCommandBuilder().setName('ticket').setDescription('Tickets')
        .addSubcommand(s => s.setName('setup').setDescription('Post the open-ticket panel'))
        .addSubcommand(s => s.setName('close').setDescription('Close the current ticket'))
        .addSubcommand(s => s.setName('forceclose').setDescription('Force close the current ticket (staff)'))
        .addSubcommand(s => s.setName('type-add').setDescription('Add a ticket type to the panel')
            .addStringOption(o => o.setName('name').setDescription('Type name, e.g. General Support').setRequired(true))
            .addStringOption(o => o.setName('emoji').setDescription('Emoji shown in the dropdown'))
            .addStringOption(o => o.setName('description').setDescription('Short description in the dropdown'))
            .addChannelOption(o => o.setName('category').setDescription('Category to create these tickets under').addChannelTypes(ChannelType.GuildCategory))
            .addRoleOption(o => o.setName('ping_role').setDescription('Role pinged when this type opens'))
            .addStringOption(o => o.setName('support_roles').setDescription('Extra support role IDs (comma-separated)')))
        .addSubcommand(s => s.setName('type-remove').setDescription('Remove a ticket type')
            .addStringOption(o => o.setName('id').setDescription('Type id (see /ticket type-list)').setRequired(true)))
        .addSubcommand(s => s.setName('type-list').setDescription('List configured ticket types')),
    new SlashCommandBuilder().setName('forward').setDescription('Forward this ticket to another team'),
    new SlashCommandBuilder().setName('close-all-tickets').setDescription('Force close all tickets'),
    new SlashCommandBuilder().setName('adduser').setDescription('Add a user to this ticket')
        .addUserOption(o => o.setName('user').setDescription('User').setRequired(true)),
    new SlashCommandBuilder().setName('removeuser').setDescription('Remove a user from this ticket')
        .addUserOption(o => o.setName('user').setDescription('User').setRequired(true))
];
export const owns = ['ticket', 'forward', 'close-all-tickets', 'adduser', 'removeuser'];
export const prefixOwns = ['ticket'];
export const componentNs = ['ticket'];

export async function handleSlash(interaction) {
    const g = interaction.guild;
    const name = interaction.commandName;

    if (name === 'ticket') {
        const sub = interaction.options.getSubcommand();

        if (sub === 'setup') {
            if (!isStaff(interaction.member)) return interaction.reply({ embeds: [errEmbed('Staff only.')], ephemeral: true });
            const p = panel({ guildId: g.id, kind: 'tickets', title: '🎫 Support Tickets', body: types(g.id).length ? 'Need help? Pick a category below to open a private ticket with our staff team.' : 'Need help? Click the button below to open a private ticket with our staff team.', footer: branding(g.id).name || undefined });
            p.components.push(panelComponents(g.id));
            const ch = await resolveChannel(g, cfg(g.id).ticketPanelChannel) || interaction.channel;
            await ch.send(p);
            return interaction.reply({ embeds: [okEmbed(`✅ Ticket panel posted in ${ch}.`)], ephemeral: true });
        }

        if (sub === 'type-add') {
            if (!isStaff(interaction.member)) return interaction.reply({ embeds: [errEmbed('Staff only.')], ephemeral: true });
            const label = interaction.options.getString('name');
            let id = slugify(label), n = 1;
            while (types(g.id).some(t => t.id === id)) id = `${slugify(label)}-${++n}`;
            const t = {
                id, label,
                emoji: interaction.options.getString('emoji') || null,
                description: interaction.options.getString('description') || null,
                category: interaction.options.getChannel('category')?.id || null,
                pingRole: interaction.options.getRole('ping_role')?.id || null,
                supportRoles: interaction.options.getString('support_roles') || null
            };
            types(g.id).push(t); persist();
            return interaction.reply({ embeds: [okEmbed(`✅ Added ticket type **${label}** (id \`${id}\`). Re-run \`/ticket setup\` to refresh the panel.`)], ephemeral: true });
        }
        if (sub === 'type-remove') {
            if (!isStaff(interaction.member)) return interaction.reply({ embeds: [errEmbed('Staff only.')], ephemeral: true });
            const id = interaction.options.getString('id');
            const arr = types(g.id);
            const idx = arr.findIndex(t => t.id === id);
            if (idx === -1) return interaction.reply({ embeds: [errEmbed(`No ticket type with id \`${id}\`.`)], ephemeral: true });
            arr.splice(idx, 1); persist();
            return interaction.reply({ embeds: [okEmbed(`✅ Removed ticket type \`${id}\`. Re-run \`/ticket setup\` to refresh the panel.`)], ephemeral: true });
        }
        if (sub === 'type-list') {
            const arr = types(g.id);
            const lines = arr.map(t => `${t.emoji ? t.emoji + ' ' : ''}**${t.label}** \`${t.id}\`${t.category ? ` → <#${t.category}>` : ''}${t.pingRole ? ` · pings <@&${t.pingRole}>` : ''}`);
            return interaction.reply({ embeds: [okEmbed(lines.join('\n') || 'No ticket types configured — the panel shows a single "Open Ticket" button.', '🎫 Ticket Types')], ephemeral: true });
        }

        // close / forceclose
        const t = guild(g.id).tickets[interaction.channel.id];
        if (!t) return interaction.reply({ embeds: [errEmbed('This is not a ticket channel.')], ephemeral: true });
        if (sub === 'forceclose' && !isSupport(interaction.member, cfg(g.id))) return interaction.reply({ embeds: [errEmbed('Staff only.')], ephemeral: true });
        if (sub === 'close' && !isSupport(interaction.member, cfg(g.id)) && interaction.user.id !== t.userId)
            return interaction.reply({ embeds: [errEmbed('Only staff or the ticket owner can close.')], ephemeral: true });
        await interaction.reply({ embeds: [okEmbed('Closing ticket…')], ephemeral: true });
        return closeTicket(g, interaction.channel, interaction.user);
    }

    if (name === 'forward') {
        const t = guild(g.id).tickets[interaction.channel.id];
        if (!t) return interaction.reply({ embeds: [errEmbed('Run this inside a ticket channel.')], ephemeral: true });
        if (!isSupport(interaction.member, cfg(g.id))) return interaction.reply({ embeds: [errEmbed('Staff only.')], ephemeral: true });
        const list = types(g.id);
        if (!list.length) return interaction.reply({ embeds: [errEmbed('No ticket types configured to forward to.')], ephemeral: true });
        const menu = new StringSelectMenuBuilder().setCustomId('ticket:forward').setPlaceholder('Forward to…');
        for (const ty of list.slice(0, 25)) {
            const opt = { label: ty.label.slice(0, 100), value: ty.id, description: (ty.description || '').slice(0, 100) || undefined };
            if (ty.emoji) opt.emoji = ty.emoji;
            menu.addOptions(opt);
        }
        return interaction.reply({ embeds: [infoEmbed('📨 Forward Ticket', 'Choose which team to forward this ticket to:')], components: [new ActionRowBuilder().addComponents(menu)], ephemeral: true });
    }

    if (name === 'close-all-tickets') {
        if (!isAdmin(interaction.member)) return interaction.reply({ embeds: [errEmbed('Admin only.')], ephemeral: true });
        await interaction.deferReply({ ephemeral: true });
        let n = 0;
        for (const cid of Object.keys(guild(g.id).tickets)) {
            const ch = g.channels.cache.get(cid);
            if (ch && await closeTicket(g, ch, interaction.user)) n++;
            else { delete guild(g.id).tickets[cid]; persist(); }
        }
        return interaction.editReply({ embeds: [okEmbed(`✅ Closed ${n} ticket(s).`)] });
    }

    if (name === 'adduser' || name === 'removeuser') {
        const t = guild(g.id).tickets[interaction.channel.id];
        if (!t) return interaction.reply({ embeds: [errEmbed('This is not a ticket channel.')], ephemeral: true });
        if (!isSupport(interaction.member, cfg(g.id)) && interaction.user.id !== t.userId)
            return interaction.reply({ embeds: [errEmbed('Only staff or the ticket owner can do that.')], ephemeral: true });
        const user = interaction.options.getUser('user');
        if (name === 'adduser') {
            await interaction.channel.permissionOverwrites.edit(user.id, { ViewChannel: true, SendMessages: true, ReadMessageHistory: true });
            return interaction.reply({ embeds: [okEmbed(`✅ Added ${user} to the ticket.`)] });
        }
        await interaction.channel.permissionOverwrites.delete(user.id).catch(() => {});
        return interaction.reply({ embeds: [okEmbed(`✅ Removed ${user} from the ticket.`)] });
    }
}

export async function handleComponent(interaction) {
    const [, action] = interaction.customId.split(':');
    const g = interaction.guild;

    if (action === 'open') {
        const existing = Object.entries(guild(g.id).tickets).find(([, t]) => t.userId === interaction.user.id);
        if (existing) return interaction.reply({ embeds: [errEmbed(`You already have an open ticket: <#${existing[0]}>`)], ephemeral: true });
        // Dropdown selection carries the type id; the fallback button has none.
        const type = interaction.isStringSelectMenu()
            ? types(g.id).find(t => t.id === interaction.values[0]) || null
            : null;
        await interaction.deferReply({ ephemeral: true });
        const ch = await createTicket(g, interaction.member, type);
        return interaction.editReply({ embeds: [okEmbed(`✅ Ticket created: ${ch}`)] });
    }

    const t = guild(g.id).tickets[interaction.channel.id];
    if (!t) return interaction.reply({ embeds: [errEmbed('This is not a ticket channel.')], ephemeral: true });

    if (action === 'claim') {
        if (!isSupport(interaction.member, cfg(g.id))) return interaction.reply({ embeds: [errEmbed('Only staff can claim tickets.')], ephemeral: true });
        const uid = interaction.user.id;
        let notice;
        if (!t.claimedBy) {                                   // claim
            t.claimedBy = uid; notice = `🟢 Ticket claimed by ${interaction.user}.`;
        } else if (t.claimedBy === uid) {                     // unclaim your own
            t.claimedBy = null; notice = `🔴 Ticket unclaimed by ${interaction.user}.`;
        } else if (isAdmin(interaction.member)) {             // admin takeover
            t.claimedBy = uid; notice = `🟢 Ticket reassigned to ${interaction.user} (admin).`;
        } else {
            return interaction.reply({ embeds: [errEmbed(`Already claimed by <@${t.claimedBy}>. Only they or an admin can change it.`)], ephemeral: true });
        }
        persist();
        await interaction.channel.setName(ticketChannelName(!!t.claimedBy, t.username || interaction.channel.name)).catch(() => {});
        await interaction.update(ticketPanel(g.id, t));        // refresh the panel (button + status)
        return interaction.channel.send({ embeds: [okEmbed(notice)] }).catch(() => {});
    }
    if (action === 'close') {
        if (!isSupport(interaction.member, cfg(g.id)) && interaction.user.id !== t.userId)
            return interaction.reply({ embeds: [errEmbed('Only staff or the ticket owner can close.')], ephemeral: true });
        await interaction.reply({ embeds: [okEmbed('Closing ticket…')], ephemeral: true });
        return closeTicket(g, interaction.channel, interaction.user);
    }
    if (action === 'forward') {
        if (!isSupport(interaction.member, cfg(g.id))) return interaction.reply({ embeds: [errEmbed('Staff only.')], ephemeral: true });
        const target = types(g.id).find(x => x.id === interaction.values[0]);
        if (!target) return interaction.reply({ embeds: [errEmbed('That ticket type no longer exists.')], ephemeral: true });
        const parent = target.category || cfg(g.id).ticketCategory || null;
        if (parent) await interaction.channel.setParent(parent, { lockPermissions: false }).catch(() => {});
        for (const rid of supportRoleIds(g, target)) {
            if (g.roles.cache.has(rid)) await interaction.channel.permissionOverwrites.edit(rid, { ViewChannel: true, SendMessages: true, ReadMessageHistory: true }).catch(() => {});
        }
        t.type = target.id; persist();
        // Refresh the in-ticket panel to show the new team.
        const pm = t.panelMessageId && await interaction.channel.messages.fetch(t.panelMessageId).catch(() => null);
        if (pm) await pm.edit(ticketPanel(g.id, t)).catch(() => {});
        await interaction.update({ embeds: [okEmbed(`✅ Forwarded to **${target.label}**.`)], components: [] });
        const ping = target.pingRole ? `<@&${target.pingRole}>` : '';
        return interaction.channel.send({ content: ping || undefined, embeds: [infoEmbed('📨 Ticket Forwarded', `This ticket was forwarded to **${target.label}** by ${interaction.user}.`)], allowedMentions: { roles: target.pingRole ? [target.pingRole] : [] } }).catch(() => {});
    }
}

export async function handlePrefix(cmd, message, args) {
    if ((args[0] || '').toLowerCase() !== 'close') return message.reply({ embeds: [errEmbed('Usage: `u!ticket close`')] }).catch(() => {});
    const t = guild(message.guild.id).tickets[message.channel.id];
    if (!t) return message.reply({ embeds: [errEmbed('This is not a ticket channel.')] }).catch(() => {});
    if (!isSupport(message.member, cfg(message.guild.id)) && message.author.id !== t.userId)
        return message.reply({ embeds: [errEmbed('Only staff or the ticket owner can close.')] }).catch(() => {});
    return closeTicket(message.guild, message.channel, message.author);
}
